
"""
Database module for betting analysis system
"""
